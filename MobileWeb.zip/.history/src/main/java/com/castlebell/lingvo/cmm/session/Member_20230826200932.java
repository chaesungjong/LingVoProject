package com.castlebell.lingvo.cmm.session;
import java.io.Serializable;

public class Member implements Serializable {

    private static final long serialVersionUID = 1L;

    private String userid;
    private String userkey;
    private String pwd;
    private String name;
    private String hpno;
    private String birthday;
    private String gender;
    private String companyName;
    private String workType;
    private String grade;
    private String state;
    private String appUseYN;
    private String mngUseYN;
    private String systemtime;
    private String siteCode;
    private String siteName;
    private String siteCompanyName;
    private String siteAddress;
    private String siteSubAddr1;
    private String siteSubAddr2;
    private String siteState;
    private String constCode;
    private String constName;
    private String constState;
    private String svgCode;
    private String svgName;
    private String svgRegion;
    private String svgState;
    private String todayWorkYN;

    // Getter and Setter methods
    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getUserkey() {
        return userkey;
    }   

    public void setUserkey(String userkey) {
        this.userkey = userkey;
    }       

    public String getPwd() {
        return pwd;
    }       

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }       

    public String getName() {
        return name;
    }       

    public void setName(String name) {
        this.name = name;
    }       

    public String getHpno() {
        return hpno;
    }       

    public void setHpno(String hpno) {
        this.hpno = hpno;
    }       

    public String getBirthday() {
        return birthday;
    }       

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }       

    public String getTodayWorkYN() {
        return todayWorkYN;
    }

    public void setTodayWorkYN(String todayWorkYN) {
        this.todayWorkYN = todayWorkYN;
    }

    @Override
    public String toString() {
        return "Member [userid=" + userid + ", userkey=" + userkey + ", pwd=" + pwd + ", name=" + name + ", hpno=" + hpno + ", birthday=" + birthday + ", gender=" + gender + ", ... ]";  // 추가 필드들을 이곳에 추가하십시오.
    }
}