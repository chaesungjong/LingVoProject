package com.castlebell.lingvo.work.controller.manager;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import com.castlebell.lingvo.cmm.CommonController;


/**
 * @since 2023. 8. 28.
 * @version 1.0
 * <pre>
 * 작업 후기 컨트롤러
 * </pre>
 */
@Controller
@RequestMapping("work/manager/Stop")
public class StopController extends CommonController {
    
}
