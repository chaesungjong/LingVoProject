package com.castlebell.lingvo.weather.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import com.castlebell.lingvo.cmm.CommonController;
import com.castlebell.lingvo.work.controller.worker.EndWorkController;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;

/**
 * @since 2023. 8. 12.
 * @version 1.0
 * <pre>
 * 날씨 컨트롤러
 * </pre>
 */
@Controller
@RequestMapping("Weather")
public class WeatherController extends CommonController {

    private static final Logger logger = LoggerFactory.getLogger(WeatherController.class);
    
}
