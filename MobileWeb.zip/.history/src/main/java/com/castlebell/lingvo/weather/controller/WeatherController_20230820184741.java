package com.castlebell.lingvo.weather.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import com.castlebell.lingvo.cmm.CommonController;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;

/**
 * @since 2023. 8. 12.
 * @version 1.0
 * <pre>
 * 날씨 컨트롤러
 * </pre>
 */
@Controller
@RequestMapping("Weather")
public class WeatherController extends CommonController {

    private static final Logger logger = LoggerFactory.getLogger(WeatherController.class);

    private final String API_URL = "https://apis.data.go.kr/1360000/VilageFcstInfoService_2.0/getUltraSrtNcst";
    private final String SERVICE_KEY = "YOUR_SERVICE_KEY"; // 서비스 키를 여기에 넣으세요.

    @GetMapping("/weather")
    public ResponseEntity<String> fetchWeather(HttpServletRequest request) {
        RestTemplate restTemplate = new RestTemplate();

        // HttpServletRequest로부터 데이터 추출
        String pageNo = request.getParameter("pageNo");      // 페이지 번호
        String numOfRows = request.getParameter("numOfRows"); // 행의 수
        String dataType = request.getParameter("dataType");   // 데이터 타입
        String baseDate = request.getParameter("base_date");  // 기준 날짜
        String baseTime = request.getParameter("base_time");  // 기준 시간
        String nx = request.getParameter("nx");               // x 좌표 값
        String ny = request.getParameter("ny");               // y 좌표 값

        // 파라미터를 URL에 추가
        String parameters = "?serviceKey=" + SERVICE_KEY
                            + "&pageNo=" + (pageNo == null ? "1" : pageNo)
                            + "&numOfRows=" + (numOfRows == null ? "1000" : numOfRows)
                            + "&dataType=" + (dataType == null ? "JSON" : dataType)
                            + "&base_date=" + (baseDate == null ? "20230820" : baseDate)
                            + "&base_time=" + (baseTime == null ? "0600" : baseTime)
                            + "&nx=" + (nx == null ? "55" : nx)
                            + "&ny=" + (ny == null ? "127" : ny);

        String result = restTemplate.getForObject(API_URL + parameters, String.class);

        return ResponseEntity.ok(result);
    }
    
}
