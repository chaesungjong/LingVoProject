package com.castlebell.lingvo.work.controller.manager;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import com.castlebell.lingvo.cmm.CommonController;
import com.castlebell.lingvo.cmm.session.Member;
import com.castlebell.lingvo.work.dao.domain.request.StateMySiteInfoRequest;
import com.castlebell.lingvo.work.dao.domain.response.StatMySiteInfoRegionAllResponse;
import com.castlebell.lingvo.work.dao.domain.response.StatMySiteInfoRegionCompanyResponse;
import com.castlebell.lingvo.work.dao.domain.response.StatMySiteInfoRegionSiteResponse;
import com.castlebell.lingvo.work.dao.domain.response.StatMySiteInfoWorkAllResponse;
import com.castlebell.lingvo.work.service.ManagerService;
import com.castlebell.lingvo.work.util.StringUtil;

/**
 * @since 2023. 8. 13.
 * @version 1.0
 * <pre>
 * 현장 정보 컨트롤러
 * </pre>
 */
@Controller
@RequestMapping("work/manager/fieldinformation")
public class FieldInformationController extends CommonController {

    @Autowired
    private ManagerService managerService;
    private static final Logger logger = LoggerFactory.getLogger(FieldInformationController.class);

    /**
     * MY 현장 정보 메인 페이지
     * @return 현장 정보 리스트 페이지 URL
     */
    @RequestMapping(value = "/fieldinformationlist", method = RequestMethod.GET)
    public String fieldinformationlist(HttpServletRequest request, Model model, HttpSession session, RedirectAttributes redirectAttributes) {

        logger.debug("fieldinformationlist 진입");
        if (checkLogin(session, redirectAttributes) == false ) return "redirect:/mmb/login";
        return FieldInformationMapping + "/fieldinformationlist";
    }

    /**
     * MY 현장 정보 (전체보기)
     * @return  현장 정보 (전체보기) URL
     */
    @RequestMapping(value = "/myFieldInfoToday", method = RequestMethod.GET)
    public String myFieldInfoToday(HttpServletRequest request, Model model, HttpSession session, RedirectAttributes redirectAttributes) {

        logger.debug("myFieldInfoToday 진입");
        if (checkLogin(session, redirectAttributes) == false ) return "redirect:/mmb/login";
        Member member = (Member) session.getAttribute("member");
        StateMySiteInfoRequest stateMySiteInfoRequest = createStateMySiteInfoRequest("WORK_ALL", member.getUserid(), member.getGrade(), member.getSvgCode(), member.getsiteCode(),member.getSvgRegion(), "", "", "", "", "", "");
        StatMySiteInfoWorkAllResponse result = managerService.statMySiteInfoWorkAllResponse(stateMySiteInfoRequest);
        model.addAttribute("result", result);
        return FieldInformationMapping + "/myFieldInfoToday";
    }

    /**
     * MY 현장 정보 메인 페이지
     * @return 현장 정보 리스트 페이지 URL
     */
    @RequestMapping(value = "/myFieldInfoAll", method = RequestMethod.GET)
    public String myFieldInfoAll(HttpServletRequest request, Model model, HttpSession session, RedirectAttributes redirectAttributes) {

        logger.debug("myFieldInfoAll 진입");

        if (checkLogin(session, redirectAttributes) == false ) return "redirect:/mmb/login";

        Member member = (Member) session.getAttribute("member");

        StateMySiteInfoRequest stateMySiteInfoRequest = createStateMySiteInfoRequest("REGION_ALL", member.getUserid(), member.getGrade(), member.getSvgCode(), member.getsiteCode(), member.getSvgRegion(),member.getSiteCompanyName(), "", "", "", "", "");
        List<StatMySiteInfoRegionAllResponse> result = managerService.statMySiteInfoRegionAllResponse(stateMySiteInfoRequest);
        model.addAttribute("result", result); // 구분
        return FieldInformationMapping + "/myFieldInfoAll";
    }

    /**
     * MY 현장 정보 메인 페이지
     * @return 현장 정보 리스트 페이지 URL
     */
    @RequestMapping(value = "/myFieldInfoField", method = RequestMethod.GET)
    public String myFieldInfoField(HttpServletRequest request, Model model, HttpSession session, RedirectAttributes redirectAttributes) {

        logger.debug("myFieldInfoAll 진입");


        // 로그인 체크
        if (checkLogin(session, redirectAttributes) == false ) return "redirect:/mmb/login";
        StateMySiteInfoRequest StateMySiteInfoRequest = new StateMySiteInfoRequest();
        StateMySiteInfoRequest.setGubun("REGION_SITE");
        StateMySiteInfoRequest.setUserid("daesung");
        StateMySiteInfoRequest.setGrade("S1");
        StateMySiteInfoRequest.setSvgCode("sacheon");
        StateMySiteInfoRequest.setSiteCode("");
        StateMySiteInfoRequest.setRegionName(StringUtil.objectToString(request.getParameter("siteSubAddr2")));
        StateMySiteInfoRequest.setCompnayName("");
        StateMySiteInfoRequest.setSdate("");
        StateMySiteInfoRequest.setEdate("");
        StateMySiteInfoRequest.setPageNo("");
        StateMySiteInfoRequest.setPageSize("");
        StateMySiteInfoRequest.setEtcParam("");

        List<StatMySiteInfoRegionSiteResponse> result = managerService.statMySiteInfoRegionSiteResponse(StateMySiteInfoRequest);
        model.addAttribute("result", result); // 구분
        return FieldInformationMapping + "/myFieldInfoField";
    }


    /**
     * MY 현장 정보 메인 페이지
     * @return 현장 정보 리스트 페이지 URL
     */
    @RequestMapping(value = "/myFieldInfoCompany", method = RequestMethod.GET)
    public String myFieldInfoCompany(HttpServletRequest request, Model model, HttpSession session, RedirectAttributes redirectAttributes) {

        logger.debug("myFieldInfoAll 진입");


        // 로그인 체크
        if (checkLogin(session, redirectAttributes) == false ) return "redirect:/mmb/login";

        StateMySiteInfoRequest StateMySiteInfoRequest = new StateMySiteInfoRequest();
        StateMySiteInfoRequest.setGubun("REGION_COMPANY");
        StateMySiteInfoRequest.setUserid("daesung");
        StateMySiteInfoRequest.setGrade("S1");
        StateMySiteInfoRequest.setSvgCode("");
        StateMySiteInfoRequest.setSiteCode("");
        StateMySiteInfoRequest.setSiteCode("ST_0000001");
        StateMySiteInfoRequest.setRegionName(StringUtil.objectToString(request.getParameter("siteSubAddr2")));
        StateMySiteInfoRequest.setCompnayName("");
        StateMySiteInfoRequest.setSdate("");
        StateMySiteInfoRequest.setEdate("");
        StateMySiteInfoRequest.setPageNo("");
        StateMySiteInfoRequest.setPageSize("");
        StateMySiteInfoRequest.setEtcParam("");

        List<StatMySiteInfoRegionCompanyResponse> result = managerService.statMySiteInfoRegionCompanyResponse(StateMySiteInfoRequest);
        model.addAttribute("result", result); // 구분
        return FieldInformationMapping + "/myFieldInfoCompany";
    }

    /**
     * MY 현장 정보 메인 페이지
     * @return 현장 정보 리스트 페이지 URL
     */
    @RequestMapping(value = "/myFieldInfoEmployee", method = RequestMethod.GET)
    public String myFieldInfoEmployee(HttpServletRequest request, Model model, HttpSession session, RedirectAttributes redirectAttributes) {

        logger.debug("myFieldInfoEmployee 진입");


        // 로그인 체크
        if (checkLogin(session, redirectAttributes) == false ) return "redirect:/mmb/login";

        StateMySiteInfoRequest StateMySiteInfoRequest = new StateMySiteInfoRequest();
        StateMySiteInfoRequest.setGubun("REGION_COMPANY");
        StateMySiteInfoRequest.setUserid("daesung");
        StateMySiteInfoRequest.setGrade("S1");
        StateMySiteInfoRequest.setSvgCode("");
        StateMySiteInfoRequest.setSiteCode("");
        StateMySiteInfoRequest.setSiteCode("ST_0000001");
        StateMySiteInfoRequest.setRegionName(StringUtil.objectToString(request.getParameter("siteSubAddr2")));
        StateMySiteInfoRequest.setCompnayName("");
        StateMySiteInfoRequest.setSdate("");
        StateMySiteInfoRequest.setEdate("");
        StateMySiteInfoRequest.setPageNo("");
        StateMySiteInfoRequest.setPageSize("");
        StateMySiteInfoRequest.setEtcParam("");

        List<StatMySiteInfoRegionCompanyResponse> result = managerService.statMySiteInfoRegionCompanyResponse(StateMySiteInfoRequest);
        model.addAttribute("result", result); // 구분
        return FieldInformationMapping + "/myFieldInfoEmployee";
    }

        /**
     * MY 현장 정보 메인 페이지
     * @return 현장 정보 리스트 페이지 URL
     */
    @RequestMapping(value = "/myFieldInfoStop", method = RequestMethod.GET)
    public String myFieldInfoStop(HttpServletRequest request, Model model, HttpSession session, RedirectAttributes redirectAttributes) {

        logger.debug("myFieldInfoStop 진입");


        // 로그인 체크
        if (checkLogin(session, redirectAttributes) == false ) return "redirect:/mmb/login";

        StateMySiteInfoRequest StateMySiteInfoRequest = new StateMySiteInfoRequest();
        StateMySiteInfoRequest.setGubun("REGION_WORKSTOP");
        StateMySiteInfoRequest.setUserid("daesung");
        StateMySiteInfoRequest.setGrade("S1");
        StateMySiteInfoRequest.setSvgCode("");
        StateMySiteInfoRequest.setSiteCode("");
        StateMySiteInfoRequest.setSiteCode("ST_0000001");
        StateMySiteInfoRequest.setRegionName(StringUtil.objectToString(request.getParameter("siteSubAddr2")));
        StateMySiteInfoRequest.setCompnayName("대성도배");
        StateMySiteInfoRequest.setSdate("20230807");
        StateMySiteInfoRequest.setEdate("");
        StateMySiteInfoRequest.setPageNo("");
        StateMySiteInfoRequest.setPageSize("");
        StateMySiteInfoRequest.setEtcParam("");

        List<StatMySiteInfoRegionCompanyResponse> result = managerService.statMySiteInfoRegionCompanyResponse(StateMySiteInfoRequest);
        model.addAttribute("result", result); // 구분
        return FieldInformationMapping + "/myFieldInfoStop";
    }
  

    /**
     * 사용자의 선택에 따른 My현장정보 통계 요청 데이터 설정
     * @param gubun     통계 구분 (WORK_ALL, REGION_ALL, REGION_SITE, REGION_COMPANY, REGION_WORKSTOP)
     * @param userid    사용자 아이디
     * @param grade     등급
     * @param svgCode   SVG 코드
     * @param siteCode  현장 코드
     * @param regionName 지역명
     * @param compnayName 회사명
     * @param sdate     시작 날짜
     * @param edate     종료 날짜
     * @param pageNo    페이지 번호
     * @param pageSize  페이지 크기
     * @param etcParam  기타 파라미터
     * @return My현장정보 통계 요청 데이터
     */
    private StateMySiteInfoRequest createStateMySiteInfoRequest(
            String gubun, String userid, String grade, String svgCode,
            String siteCode, String regionName, String compnayName,
            String sdate, String edate, String pageNo, String pageSize,
            String etcParam) {
        StateMySiteInfoRequest stateMySiteInfoRequest = new StateMySiteInfoRequest();
        stateMySiteInfoRequest.setGubun(gubun);
        stateMySiteInfoRequest.setUserid(userid);
        stateMySiteInfoRequest.setGrade(grade);
        stateMySiteInfoRequest.setSvgCode(svgCode);
        stateMySiteInfoRequest.setSiteCode(siteCode);
        stateMySiteInfoRequest.setRegionName(regionName);
        stateMySiteInfoRequest.setCompnayName(compnayName);
        stateMySiteInfoRequest.setSdate(sdate);
        stateMySiteInfoRequest.setEdate(edate);
        stateMySiteInfoRequest.setPageNo(pageNo);
        stateMySiteInfoRequest.setPageSize(pageSize);
        stateMySiteInfoRequest.setEtcParam(etcParam);
        return stateMySiteInfoRequest;
    }

    /**
     * My현장정보 통계 요청 데이터 생성 메서드
     * @param member     회원 정보 객체
     * @param gubun      통계 구분 (WORK_ALL, REGION_ALL 등)
     * @param sdate      시작 날짜
     * @param edate      종료 날짜
     * @param pageNo     페이지 번호
     * @param pageSize   페이지 크기
     * @param etcParam   기타 파라미터
     * @return My현장정보 통계 요청 데이터
     */
    private StateMySiteInfoRequest createStateMySiteInfoRequest(
            Member member, String gubun, String sdate, String edate,
            String pageNo, String pageSize, String etcParam) {
        // My현장정보 통계 요청 데이터 객체 생성
        StateMySiteInfoRequest stateMySiteInfoRequest = new StateMySiteInfoRequest();
        
        // 통계 구분 설정
        stateMySiteInfoRequest.setGubun(gubun);
        
        // 회원 정보 설정
        stateMySiteInfoRequest.setUserid(member.getUserid());
        stateMySiteInfoRequest.setGrade(member.getGrade());
        stateMySiteInfoRequest.setSvgCode(member.getSvgCode());
        stateMySiteInfoRequest.setSiteCode(member.getSiteCode());
        stateMySiteInfoRequest.setRegionName(member.getSvgRegion());
        stateMySiteInfoRequest.setCompnayName(member.getCompanyName());
        
        // 날짜 및 페이지 설정
        stateMySiteInfoRequest.setSdate(sdate);
        stateMySiteInfoRequest.setEdate(edate);
        stateMySiteInfoRequest.setPageNo(pageNo);
        stateMySiteInfoRequest.setPageSize(pageSize);
        
        // 기타 파라미터 설정
        stateMySiteInfoRequest.setEtcParam(etcParam);
        
        // 생성된 통계 요청 데이터 반환
        return stateMySiteInfoRequest;
    }






}