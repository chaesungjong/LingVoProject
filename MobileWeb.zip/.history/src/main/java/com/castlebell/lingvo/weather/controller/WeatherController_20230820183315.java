package com.castlebell.lingvo.weather.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import com.castlebell.lingvo.cmm.CommonController;
import org.springframework.stereotype.Controller;

/**
 * @since 2023. 8. 12.
 * @version 1.0
 * <pre>
 * 작업 종료 컨트롤러
 * </pre>
 */
@Controller
@RequestMapping("Weather")
public class WeatherController extends CommonController {
    
}
