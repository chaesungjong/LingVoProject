package com.castlebell.lingvo.weather.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import com.castlebell.lingvo.cmm.CommonController;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import java.util.Date;

/**
 * @since 2023. 8. 20.
 * @version 1.0
 * <pre>
 * 날씨 컨트롤러
 * </pre>
 */
@Controller
@RequestMapping("Weather")
public class WeatherController extends CommonController {

    private static final Logger logger = LoggerFactory.getLogger(WeatherController.class);

    private final String API_URL = "https://apis.data.go.kr/1360000/VilageFcstInfoService_2.0/getVilageFcst";
    private final String SERVICE_KEY = "aHyZIj5gRgCJntRQEmnoJU9hD3U8kZHG8fH7eOrbmZruxk52uy75w0V0v5Rsss5SpdmZYc3S7azQ2ctDxItwig=="; // 서비스 키를 여기에 넣으세요.


    @GetMapping("/nextWeekForecast")
    public List<String> fetchNextWeekForecast(HttpServletRequest request) {
        RestTemplate restTemplate = new RestTemplate();
        
        List<String> results = new ArrayList<>();
    
        // 현재 날짜 및 시간을 Date 클래스를 사용해 가져옴
        Date currentDate = new Date();
        SimpleDateFormat dateSdf = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat timeSdf = new SimpleDateFormat("HHmm");
        String currentTime = timeSdf.format(currentDate);
        
        // nx와 ny 값을 request에서 가져옴
        String nx = request.getParameter("nx");
        String ny = request.getParameter("ny");
        
        // 입력값 검증 (옵션)
        if (nx == null || ny == null) {
            // 적절한 오류 메시지 또는 처리를 수행
            return results;  // 예제에서는 빈 결과 반환
        }
    
        for (int i = 1; i <= 7; i++) {  // 오늘부터 7일 후까지
            String baseDate = dateSdf.format(new Date(currentDate.getTime() + (long)i * 24 * 60 * 60 * 1000));
    
            // 파라미터를 URL에 추가
            String parameters = "?serviceKey=" + SERVICE_KEY
                                + "&base_date=" + baseDate
                                + "&base_time=" + currentTime
                                + "&nx=" + nx
                                + "&ny=" + ny
                                + "&dataType=JSON" 
                                +  "&pageNo=" + "1"
                                + "&numOfRows=" + "1000";
    
            String result = restTemplate.getForObject(API_URL + parameters, String.class);
    
            results.add(result);
        }
    
        return results;
    }
}

https://apis.data.go.kr/1360000/VilageFcstInfoService_2.0/getUltraSrtNcst?serviceKey=aHyZIj5gRgCJntRQEmnoJU9hD3U8kZHG8fH7eOrbmZruxk52uy75w0V0v5Rsss5SpdmZYc3S7azQ2ctDxItwig%3D%3D&pageNo=1&numOfRows=1000&dataType=XML&base_date=20230820&base_time=0600&nx=55&ny=127