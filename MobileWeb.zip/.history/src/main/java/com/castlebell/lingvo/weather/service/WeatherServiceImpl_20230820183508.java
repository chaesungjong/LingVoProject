package com.castlebell.lingvo.weather.service;

public class WeatherServiceImpl implements weatherService{
    
}
